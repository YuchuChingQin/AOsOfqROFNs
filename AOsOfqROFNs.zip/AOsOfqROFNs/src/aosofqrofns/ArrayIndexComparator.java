/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aosofqrofns;

/**
 *
 * @developer: Peizhi Shi
 * @email: peizhi.shi@manchester.ac.uk
 * 
 */
import java.util.*;

public class ArrayIndexComparator implements Comparator<Integer>
{
    private final double[] score;
    private final double[] accuracy;

    public ArrayIndexComparator(double[] score, double[] accuracy)
    {
        this.score = score;
        this.accuracy = accuracy;
    }

    public Integer[] createIndexArray()
    {
        Integer[] indexes = new Integer[score.length];
        for (int i = 0; i < score.length; i++)
        {
            indexes[i] = i; // Autoboxing
        }
        return indexes;
    }

    @Override
    public int compare(Integer index1, Integer index2)
    {
    	if(score[index1] > score[index2])
    		return -1;   	
    	if(score[index1] < score[index2])
    		return 1;   	
    	if (accuracy[index1] > accuracy[index2])
    		return -1;  	
    	if (accuracy[index1] < accuracy[index2])
    		return 1;    	
    	return 0;
    }
}
