/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aosofqrofns;

/**
 *
 * @developers Yuchu Qin & Peizhi Shi
 * @emails: qinyuchu@hud.ac.uk & peizhi.shi@manchester.ac.uk 
 * Operator	 Authors of the paper	 Developer	           
 * qROFWA        Liu and Wang            Yuchu Qin
 * qROFWG	 Liu and Wang 	         Yuchu Qin
 * qROFWBM       Liu and Liu 	         Yuchu Qin         
 * qROFWGBM	 Liu and Liu 	         Yuchu Qin        
 * qROFWAABM     Liu and Wang            Yuchu Qin
 * qROFWAEBM     Liu and Wang            Yuchu Qin
 * qROFWAHBM     Liu and Wang            Yuchu Qin
 * qROFWAFBM	 Liu and Wang 	         Yuchu Qin
 * qROFWAAGBM    Qin et al.              Yuchu Qin
 * qROFWAEGBM    Qin et al.              Yuchu Qin
 * qROFWAHGBM    Qin et al.              Yuchu Qin
 * qROFWAFGBM    Qin et al.              Yuchu Qin
 * qROFWHM       Wei et al.              Yuchu Qin
 * qROFWGHM	 Wei et al. 	         Yuchu Qin
 * qROFWHM       Liu et al.              Yuchu Qin        
 * qROFWMSM      Wei et al.              Peizhi Shi
 * qROFWGMSM	 Wei et al. 	         Peizhi Shi
 * qROFWMM       Wang et al. 	         Peizhi Shi
 * qROFWGMM	 Wang et al. 	         Peizhi Shi
 * qROFWAAMM     Qin et al.              Peizhi Shi        
 * qROFWAEMM     Qin et al.              Peizhi Shi & Yuchu Qin
 * qROFWAHMM     Qin et al.              Peizhi Shi & Yuchu Qin
 * qROFWAFMM     Qin et al.              Peizhi Shi & Yuchu Qin
 * qROFWAAGMM    Qin et al.              Peizhi Shi             
 * qROFWAEGMM    Qin et al.              Peizhi Shi & Yuchu Qin
 * qROFWAHGMM    Qin et al.              Peizhi Shi & Yuchu Qin
 * qROFWAFGMM    Qin et al.              Peizhi Shi & Yuchu Qin
 *
 */

import java.util.ArrayList;  
import java.util.List; 
import java.util.stream.*;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class AOsOfqROFNs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here   
        double lambda = 3.0;
        double qc = 1.0;
        int mc = 20;
        int nc = 3;           
        double[] wc = {0.35, 0.40, 0.25};
        double[] deltac = {1.0, 0.0, 0.0};
        
        double[][][] Mc = {
            {{0.5,0.4}, {0.4,0.5}, {0.4,0.2}},//A1
            {{0.5,0.3}, {0.6,0.2}, {0.5,0.2}},
            {{0.2,0.6}, {0.5,0.4}, {0.5,0.3}},
            {{0.4,0.4}, {0.5,0.3}, {0.5,0.2}},
                                  
            {{0.7,0.3}, {0.5,0.4}, {0.5,0.3}},//A2
            {{0.7,0.3}, {0.6,0.2}, {0.5,0.3}},
            {{0.6,0.2}, {0.6,0.3}, {0.6,0.2}},
            {{0.6,0.2}, {0.7,0.3}, {0.7,0.2}},//0
            //{{0.5,0.3}, {0.6,0.4}, {0.6,0.3}},//1
            //{{0.4,0.4}, {0.5,0.5}, {0.5,0.4}},//2
            //{{0.3,0.5}, {0.4,0.6}, {0.4,0.5}},//3
            //{{0.2,0.6}, {0.3,0.7}, {0.3,0.6}},//4
            //{{0.1,0.7}, {0.2,0.8}, {0.2,0.7}},//5
            //{{0.1,0.7}, {0.1,0.9}, {0.1,0.8}},//6            
                     
            {{0.5,0.4}, {0.4,0.5}, {0.4,0.4}},//A3
            {{0.6,0.4}, {0.3,0.5}, {0.3,0.4}},
            {{0.6,0.2}, {0.4,0.4}, {0.4,0.3}},
            {{0.5,0.3}, {0.2,0.6}, {0.3,0.3}},
            {{0.8,0.2}, {0.5,0.4}, {0.5,0.3}},//A4
            {{0.7,0.2}, {0.7,0.2}, {0.5,0.3}},
            {{0.4,0.2}, {0.4,0.4}, {0.3,0.5}},
            {{0.5,0.2}, {0.6,0.2}, {0.5,0.2}},
            {{0.4,0.3}, {0.6,0.3}, {0.6,0.2}},//A5
            {{0.4,0.2}, {0.7,0.2}, {0.6,0.4}},
            {{0.4,0.5}, {0.4,0.2}, {0.4,0.4}},
            {{0.4,0.6}, {0.7,0.2}, {0.6,0.3}}
        };
                                                      
        AOsOfqROFNs mcgdm = new AOsOfqROFNs();
        double[][] roa = new double[mc][2];
        for (int k = 0; k < mc; k++) {
            for (int r = 0; r < 2; r++) {
                roa[k][r] = 0.0;
            }           
        }                             
         
        //roa = mcgdm.qROFWA(mc, nc, qc, Mc, wc);
        //roa = mcgdm.qROFWG(mc, nc, qc, Mc, wc); 
        //roa = mcgdm.qROFWBM(mc, nc, qc, Mc, wc, 1.0, 0.0);
        //roa = mcgdm.qROFWGBM(mc, nc, qc, Mc, wc, 1.0, 0.0);
        //roa = mcgdm.qROFWAHBM(lambda, mc, nc, qc, Mc, wc, 1.0, 0.0);
        //roa = mcgdm.qROFWHMWEI(mc, nc, qc, Mc, wc, 1.0, 0.0);
        //roa = mcgdm.qROFWGHM(mc, nc, qc, Mc, wc, 1.0, 0.0);
        //roa = mcgdm.qROFWHMLIU(mc, nc, qc, Mc, wc, 1.0, 0.0);
        //roa = mcgdm.qROFWMSM(mc, nc, qc, Mc, wc, 1);
        //roa = mcgdm.qROFWGMSM(mc, nc, qc, Mc, wc, 1);
        //roa = mcgdm.qROFWMM(mc, nc, qc, Mc, wc, deltac); 
        //roa = mcgdm.qROFWGMM(mc, nc, qc, Mc, wc, deltac); 
        //roa = mcgdm.qROFWAHMM(lambda, mc, nc, qc, Mc, wc, deltac);
        roa = mcgdm.qROFWAHGMM(lambda, mc, nc, qc, Mc, wc, deltac);   
        
        for (int k = 0; k < mc; k++) { 
            int index = k + 1;
            System.out.println("CqROFN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(roa[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(roa[k][1]));
        }
        
        int m = 5;
        int n = 4;
        double q = 1.0;      
        double[] w = {0.2, 0.1, 0.3, 0.4};
        double[] delta = {1.0, 2.0, 3.0, 4.0};
        
         
        double[][][] M = {
            {{roa[0][0], roa[0][1]},  {roa[1][0], roa[1][1]},  {roa[2][0], roa[2][1]},  {roa[3][0], roa[3][1]}},
            {{roa[4][0], roa[4][1]},  {roa[5][0], roa[5][1]},  {roa[6][0], roa[6][1]},  {roa[7][0], roa[7][1]}},
            {{roa[8][0], roa[8][1]},  {roa[9][0], roa[9][1]},  {roa[10][0],roa[10][1]}, {roa[11][0],roa[11][1]}},
            {{roa[12][0],roa[12][1]}, {roa[13][0],roa[13][1]}, {roa[14][0],roa[14][1]}, {roa[15][0],roa[15][1]}},
            {{roa[16][0],roa[16][1]}, {roa[17][0],roa[17][1]}, {roa[18][0],roa[18][1]}, {roa[19][0],roa[19][1]}}};
        double[][] resultOfAggregation = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfAggregation[k][r] = 0.0;
            }           
        }
        
        //resultOfAggregation = mcgdm.qROFWA(m, n, q, M, w);
        //resultOfAggregation = mcgdm.qROFWG(m, n, q, M, w); 
        //resultOfAggregation = mcgdm.qROFWBM(m, n, q, M, w, 1.0, 2.0);
        //resultOfAggregation = mcgdm.qROFWGBM(m, n, q, M, w, 1.0, 2.0);
        //resultOfAggregation = mcgdm.qROFWAHBM(lambda, m, n, q, M, w, 1.0, 2.0);
        //resultOfAggregation = mcgdm.qROFWHMWEI(m, n, q, M, w, 1.0, 2.0);
        //resultOfAggregation = mcgdm.qROFWGHM(m, n, q, M, w, 1.0, 2.0);
        //resultOfAggregation = mcgdm.qROFWHMLIU(m, n, q, M, w, 1.0, 2.0);
        //resultOfAggregation = mcgdm.qROFWMSM(m, n, q, M, w, 4);
        //resultOfAggregation = mcgdm.qROFWGMSM(m, n, q, M, w, 4);
        //resultOfAggregation = mcgdm.qROFWMM(m, n, q, M, w, delta);
        //resultOfAggregation = mcgdm.qROFWGMM(m, n, q, M, w, delta);
        //resultOfAggregation = mcgdm.qROFWAHMM(lambda, m, n, q, M, w, delta);
        resultOfAggregation = mcgdm.qROFWAHGMM(lambda, m, n, q, M, w, delta);              
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("qROFN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfAggregation[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfAggregation[k][1]));
            //System.out.println(resultOfAggregation[k][0]);
            //System.out.println(resultOfAggregation[k][1]);
        }
             
        File fileWrite1 = new File("Output1.txt");
        BufferedWriter writer1 = new BufferedWriter(new FileWriter(fileWrite1, true)); 
        File fileWrite2 = new File("Output2.txt");
        BufferedWriter writer2 = new BufferedWriter(new FileWriter(fileWrite2, true));
        File fileWrite3 = new File("Output3.txt");
        BufferedWriter writer3 = new BufferedWriter(new FileWriter(fileWrite3, true));
        File fileWrite4 = new File("Output4.txt");
        BufferedWriter writer4 = new BufferedWriter(new FileWriter(fileWrite4, true)); 
        File fileWrite5 = new File("Output5.txt");
        BufferedWriter writer5 = new BufferedWriter(new FileWriter(fileWrite5, true));  
        
        double[] scoreValue = new double[m];                 
        scoreValue = mcgdm.getScoreValue(m, q, resultOfAggregation);
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            //writer1.write(String.valueOf(index) + " ");
            //writer2.write(String.valueOf(index) + " ");
            //writer3.write(String.valueOf(index) + " ");
            //writer4.write(String.valueOf(index) + " ");
            //writer5.write(String.valueOf(index) + " ");
            System.out.println("Score[" + index + "] = ");                     
            System.out.println(new java.text.DecimalFormat("#0.0000").format(scoreValue[k]));
        }
        writer1.write(String.valueOf(scoreValue[0]) + "\r\n");
        writer2.write(String.valueOf(scoreValue[1]) + "\r\n");
        writer3.write(String.valueOf(scoreValue[2]) + "\r\n");
        writer4.write(String.valueOf(scoreValue[3]) + "\r\n");
        writer5.write(String.valueOf(scoreValue[4]) + "\r\n");
        writer1.close();
        writer2.close();
        writer3.close();
        writer4.close();
        writer5.close();
        
        double[] accuracyValue = new double[m];                 
        accuracyValue = mcgdm.getAccuracyValue(m, q, resultOfAggregation);
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("Accuracy[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(accuracyValue[k]));
        }
        
        // Sort the alternatives according to thie score values and accuracy values      
	ArrayIndexComparator comparator = new ArrayIndexComparator(scoreValue, accuracyValue);
	Integer[] indexes = comparator.createIndexArray();
	Arrays.sort(indexes, comparator);
        
        // Output the ranking of the alternatives
	for(int i = 0; i < indexes.length; i++) {          
            int index = indexes[i]+1;
            System.out.print("A[" + index + "] > ");
        } 
        
        /*//Experiment 2       
        double score = 0.0;
        double[] SV = new double[m];         
        File fileWrite = new File("Output.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));       
        for (int qq = 1; qq < 11; ++qq) {                                      
            writer.write(String.valueOf(qq) + " ");               
            SV = mcgdm.getScoreValue(m, Double.valueOf(qq), mcgdm.qROFWAHGMM(lambda, m, n, Double.valueOf(qq), M, w, delta));
            score = SV[4];               
            writer.write(String.valueOf(score) + "\r\n");
        }             
        writer.close();*/
        
        /*//Experiment 3
        int nX = 1000;              
        double[] rangeX = {0.0, 20.0};              
        double stepX = ( rangeX[1] - rangeX[0] ) / ( nX - 1);           
        double[] x = new double [nX];       
        double[] score = new double [nX];
        double[] SV = new double[m];         
        File fileWrite = new File("Output.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));       
        for (int i = 0; i < nX; ++i) {            
            x[i] = rangeX[0] + i * stepX;               
            writer.write(String.valueOf(x[i]) + " ");               
            SV = mcgdm.getScoreValue(m, q, mcgdm.qROFWAHGMM(x[i], m, n, q, M, w, delta));
            score[i] = SV[4];               
            writer.write(String.valueOf(score[i]) + "\r\n");
        }             
        writer.close();*/
        
        /*//Experiment 4
        int nX = 1000;              
        double[] rangeX = {0.0, 5.0};              
        double stepX = ( rangeX[1] - rangeX[0] ) / ( nX - 1);           
        double[] x = new double [nX];       
        double[] score = new double [nX];
        double[] SV = new double[m];         
        File fileWrite = new File("Output.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));       
        for (int i = 0; i < nX; ++i) {            
            x[i] = rangeX[0] + i * stepX;               
            writer.write(String.valueOf(x[i]) + " ");  
            for (int j = 0; j < n; j++) {
                delta[j] = x[i];
            }
            SV = mcgdm.getScoreValue(m, q, mcgdm.qROFWAHGMM(lambda, m, n, q, M, w, delta));
            score[i] = SV[4];               
            writer.write(String.valueOf(score[i]) + "\r\n");
        }             
        writer.close();*/
    }
    
    //********************************************************************************//

    // Aggregate q-ROFNs using the Weighted Averaging (WA) operator in P265 of 
    // P. Liu and P. Wang, “Some q-rung orthopair fuzzy aggregation operators 
    // and their applications to multiple-attribute decision making,” 
    // International Journal of Intelligent Systems, vol. 33, no. 2, pp. 259‒280, 2018.
    public double[][] qROFWA(int m, int n, double q, double[][][] theta, double[] w) {
        double[][] resultOfqROFWA = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWA[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                
                product[k][0] = product[k][0] * Math.pow(1 - Math.pow(theta[k][i][0], q), w[i]);
                product[k][1] = product[k][1] * Math.pow(theta[k][i][1], w[i]);                        
                    
            }
            resultOfqROFWA[k][0] = Math.pow(1 - product[k][0], 1.0/q);
            resultOfqROFWA[k][1] = product[k][1];
        }
        return resultOfqROFWA;
    }
    
    // Aggregate q-ROFNs using the Weighted Geometric (WG) operator in P271 of
    // P. Liu and P. Wang, “Some q-rung orthopair fuzzy aggregation operators 
    // and their applications to multiple-attribute decision making,” 
    // International Journal of Intelligent Systems, vol. 33, no. 2, pp. 259‒280, 2018.
    public double[][] qROFWG(int m, int n, double q, double[][][] theta, double[] w) {
        double[][] resultOfqROFWG = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWG[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                
                product[k][0] = product[k][0] * Math.pow(theta[k][i][0], w[i]);
                product[k][1] = product[k][1] * Math.pow(1 - Math.pow(theta[k][i][1], q), w[i]);                        
                    
            }
            resultOfqROFWG[k][0] = product[k][0];
            resultOfqROFWG[k][1] = Math.pow(1 - product[k][1], 1.0/q);
        }
        return resultOfqROFWG;
    }
    
    //********************************************************************************//
    
    // Aggregate q-ROFNs using the Weighted Bonferroni Mean (WBM) operator in P326 of 
    // P. Liu and J. Liu, “Some q‐rung orthopair fuzzy Bonferroni mean operators and 
    // their application to multi‐attribute group decision making,” 
    // International Journal of Intelligent Systems, vol. 33, no. 2, pp. 315‒347, 2018.
    public double[][] qROFWBM(int m, int n, double q, double[][][] theta, double[] w, double s, double t) {
        double[][] resultOfqROFWBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWBM[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {                     
                        product[k][0] = product[k][0] * (1-Math.pow(
                            Math.pow(Math.pow(1-Math.pow(1-Math.pow(theta[k][i][0],q), w[i]),1.0/q),s) * 
                            Math.pow(Math.pow(1-Math.pow(1-Math.pow(theta[k][j][0],q), w[j]),1.0/q),t),q));
                        product[k][1] = product[k][1] * (1-Math.pow(
                            1 - Math.pow(theta[k][i][1], q*w[i]), s) * Math.pow(
                            1 - Math.pow(theta[k][j][1], q*w[j]), t));
                    }
                }
            }
            resultOfqROFWBM[k][0] = Math.pow(1-Math.pow(product[k][0], 1.0/(n*(n-1))), 1.0/(q*(s+t)));
            resultOfqROFWBM[k][1] = Math.pow(1-Math.pow(1-Math.pow(product[k][1], 1.0/(n*(n-1))),1.0/(s+t)), 1.0/q);
        }
        return resultOfqROFWBM;
    }
    
    // Aggregate q-ROFNs using the Weighted Geometric Bonferroni Mean (WGBM) operator in P334 of 
    // P. Liu and J. Liu, “Some q‐rung orthopair fuzzy Bonferroni mean operators and 
    // their application to multi‐attribute group decision making,” 
    // International Journal of Intelligent Systems, vol. 33, no. 2, pp. 315‒347, 2018.
    public double[][] qROFWGBM(int m, int n, double q, double[][][] theta, double[] w, double s, double t) {
        double[][] resultOfqROFWGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWGBM[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {                       
                        product[k][0] = product[k][0] * Math.pow(1 - Math.pow(1-Math.pow(theta[k][i][0], q*w[i]), s) * 
                                                        Math.pow(1-Math.pow(theta[k][j][0], q*w[j]), t), 1.0/(q*n*(n-1)));
                        product[k][1] = product[k][1] * Math.pow(1 - Math.pow(1 - Math.pow(1 - Math.pow(theta[k][i][1], q), w[i]), s) * 
                                                        Math.pow(1 - Math.pow(1 - Math.pow(theta[k][j][1], q), w[j]), t), 1.0/(n*(n-1)));
                    }
                }
            }
            resultOfqROFWGBM[k][0] = Math.pow(1 - Math.pow(1 - Math.pow(product[k][0], q), 1.0/(s+t)), 1.0/q);
            resultOfqROFWGBM[k][1] = Math.pow(1 - product[k][1], 1.0/(q*(s+t)));
        }
        return resultOfqROFWGBM;
    }
    
    //********************************************************************************//
    
    // Aggregate q-ROFNs using the Weighted Archimedean Algebraic Bonferroni Mean (WAABM) operator in P7 of
    // P. Liu and P. Wang, “Multiple-attribute decision making based on Archimedean Bonferroni operators of 
    // q-rung orthopair fuzzy numbers,” 
    // IEEE Transactions on Fuzzy Systems. DOI: 10.1109/TFUZZ.2018.2826452, 2018.
    public double[][] qROFWAABM(int m, int n, double q, double[][][] theta, double[] w, double s, double t) {
        double[][] resultOfqROFWAABM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWAABM[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        product[k][0] = product[k][0] * (1-Math.pow(
                            Math.pow(Math.pow(1-Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i]),1.0/q),s) * 
                            Math.pow(Math.pow(1-Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j]),1.0/q),t),q));
                        product[k][1] = product[k][1] * (1-Math.pow(
                            1 - Math.pow(theta[k][i][1], q*n*w[i]), s) * Math.pow(
                            1 - Math.pow(theta[k][j][1], q*n*w[j]), t));                       
                    }
                }
            }
            resultOfqROFWAABM[k][0] = Math.pow(1-Math.pow(product[k][0], 1.0/(n*(n-1))), 1.0/(q*(s+t)));
            resultOfqROFWAABM[k][1] = Math.pow(1-Math.pow(1-Math.pow(product[k][1], 1.0/(n*(n-1))),1.0/(s+t)), 1.0/q);
        }
        return resultOfqROFWAABM;
    }
    
    // Aggregate q-ROFNs using the Weighted Archimedean Einstein Bonferroni Mean (WAEBM) operator in P8 of
    // P. Liu and P. Wang, “Multiple-attribute decision making based on Archimedean Bonferroni operators of 
    // q-rung orthopair fuzzy numbers,” 
    // IEEE Transactions on Fuzzy Systems. DOI: 10.1109/TFUZZ.2018.2826452, 2018.
    public double[][] qROFWAEBM(int m, int n, double q, double[][][] theta, double[] w, double s, double t) {
        double[][] resultOfqROFWEABM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWEABM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[] a1 = new double[m];
        double[] a2 = new double[m];
        double[] b1 = new double[m];
        double[] b2 = new double[m];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m];
        
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = (2*Math.pow((Math.pow(1+Math.pow(theta[k][i][0],q), n*w[i]) - 
                               Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /
                              (Math.pow(1+Math.pow(theta[k][i][0],q), n*w[i]) + 
                               Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])), s)) / 
                              (Math.pow(2-((Math.pow(1+Math.pow(theta[k][i][0],q), n*w[i]) - 
                               Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /
                              (Math.pow(1+Math.pow(theta[k][i][0],q), n*w[i]) + 
                               Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i]))), s) + 
                               Math.pow((Math.pow(1+Math.pow(theta[k][i][0],q), n*w[i]) - 
                               Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /
                              (Math.pow(1+Math.pow(theta[k][i][0],q), n*w[i]) + 
                               Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])), s));                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = (2*Math.pow((Math.pow(1+Math.pow(theta[k][j][0],q), n*w[j]) - 
                               Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /
                              (Math.pow(1+Math.pow(theta[k][j][0],q), n*w[j]) + 
                               Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])), t)) / 
                              (Math.pow(2-((Math.pow(1+Math.pow(theta[k][j][0],q), n*w[j]) - 
                               Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /
                              (Math.pow(1+Math.pow(theta[k][j][0],q), n*w[j]) + 
                               Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j]))), t) + 
                               Math.pow((Math.pow(1+Math.pow(theta[k][j][0],q), n*w[j]) - 
                               Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /
                              (Math.pow(1+Math.pow(theta[k][j][0],q), n*w[j]) + 
                               Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])), t));                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = (Math.pow(1 + (2*Math.pow(theta[k][i][1],q*n*w[i]))/
                            (Math.pow(2-Math.pow(theta[k][i][1],q),n*w[i]) + 
                             Math.pow(theta[k][i][1],q*n*w[i])), s) - 
                             Math.pow(1 - (2*Math.pow(theta[k][i][1],q*n*w[i]))/
                            (Math.pow(2-Math.pow(theta[k][i][1],q),n*w[i]) + 
                             Math.pow(theta[k][i][1],q*n*w[i])), s))/
                            (Math.pow(1 + (2*Math.pow(theta[k][i][1],q*n*w[i]))/
                            (Math.pow(2-Math.pow(theta[k][i][1],q),n*w[i]) + 
                             Math.pow(theta[k][i][1],q*n*w[i])), s) + 
                             Math.pow(1 - (2*Math.pow(theta[k][i][1],q*n*w[i]))/
                            (Math.pow(2-Math.pow(theta[k][i][1],q),n*w[i]) + 
                             Math.pow(theta[k][i][1],q*n*w[i])), s));               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = (Math.pow(1 + (2*Math.pow(theta[k][j][1],q*n*w[j]))/
                            (Math.pow(2-Math.pow(theta[k][j][1],q),n*w[j]) + 
                             Math.pow(theta[k][j][1],q*n*w[j])), t) - 
                             Math.pow(1 - (2*Math.pow(theta[k][j][1],q*n*w[j]))/
                            (Math.pow(2-Math.pow(theta[k][j][1],q),n*w[j]) + 
                             Math.pow(theta[k][j][1],q*n*w[j])), t))/
                            (Math.pow(1 + (2*Math.pow(theta[k][j][1],q*n*w[j]))/
                            (Math.pow(2-Math.pow(theta[k][j][1],q),n*w[j]) + 
                             Math.pow(theta[k][j][1],q*n*w[j])), t) + 
                             Math.pow(1 - (2*Math.pow(theta[k][j][1],q*n*w[j]))/
                            (Math.pow(2-Math.pow(theta[k][j][1],q),n*w[j]) + 
                             Math.pow(theta[k][j][1],q*n*w[j])), t));               
            }
        }
        for (int k = 0; k < m; k++) {
            a1[k] = 1.0;
            a2[k] = 1.0;
            b1[k] = 1.0;
            b2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        a1[k] = a1[k] * (1 + (xki[k][i]*xkj[k][j])/(1+(1-xki[k][i])*(1-xkj[k][j])));
                        a2[k] = a2[k] * (1 - (xki[k][i]*xkj[k][j])/(1+(1-xki[k][i])*(1-xkj[k][j])));
                        b1[k] = b1[k] * ((yki[k][i]+ykj[k][j])/(1+yki[k][i]*ykj[k][j]));
                        b2[k] = b2[k] * (2 - ((yki[k][i]+ykj[k][j])/(1+yki[k][i]*ykj[k][j])));
                    }
                }
            }
            mu1[k] = Math.pow(1 + (a1[k]-a2[k])/(a1[k]+a2[k]), 1.0/(n*(n-1)));
            mu2[k] = Math.pow(1 - (a1[k]-a2[k])/(a1[k]+a2[k]), 1.0/(n*(n-1)));
            nu1[k] = Math.pow((2*b1[k])/(b1[k]+b2[k]), 1.0/(n*(n-1)));
            nu2[k] = Math.pow(2 - (2*b1[k])/(b1[k]+b2[k]), 1.0/(n*(n-1)));           
            resultOfqROFWEABM[k][0] = Math.pow((2*Math.pow((mu1[k]-mu2[k])/(mu1[k]+mu2[k]), 1.0/(s+t)))/
                                     (Math.pow(2-(mu1[k]-mu2[k])/(mu1[k]+mu2[k]), 1.0/(s+t))+
                                      Math.pow((mu1[k]-mu2[k])/(mu1[k]+mu2[k]), 1.0/(s+t))), 1.0/q);
            resultOfqROFWEABM[k][1] = Math.pow((Math.pow(1 + (2*nu1[k])/(nu1[k]+nu2[k]), 1.0/(s+t)) - 
                                      Math.pow(1 - (2*nu1[k])/(nu1[k]+nu2[k]), 1.0/(s+t)))/
                                     (Math.pow(1 + (2*nu1[k])/(nu1[k]+nu2[k]), 1.0/(s+t)) + 
                                      Math.pow(1 - (2*nu1[k])/(nu1[k]+nu2[k]), 1.0/(s+t))), 1.0/q);
        }
        return resultOfqROFWEABM;
    }
    
    // Aggregate q-ROFNs using the Weighted Archimedean Hamacher Bonferroni Mean (WAHBM) operator in P8 of
    // P. Liu and P. Wang, “Multiple-attribute decision making based on Archimedean Bonferroni operators of 
    // q-rung orthopair fuzzy numbers,” 
    // IEEE Transactions on Fuzzy Systems. DOI: 10.1109/TFUZZ.2018.2826452, 2018.
    public double[][] qROFWAHBM(double delta, int m, int n, double q, double[][][] theta, double[] w, double s, double t) {
        double[][] resultOfqROFWHABM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWHABM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[] a1 = new double[m];
        double[] a2 = new double[m];
        double[] b1 = new double[m];
        double[] b2 = new double[m];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m];
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = (delta*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) - 
                                   Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /
                                  (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])), s)) / 
                          (((delta-1)*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) - 
                                      Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /
                                     (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])), s)) +                      
                                      Math.pow(delta-(delta-1)*((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) - 
                                      Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /                                         
                                     (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i]))), s));                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                 xkj[k][j] = (delta*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) - 
                                    Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /
                                   (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])), t)) / 
                           (((delta-1)*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) - 
                                       Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /
                                      (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])), t)) +                      
                                       Math.pow(delta-(delta-1)*((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) - 
                                       Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /                                         
                                      (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j]))), t));                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = (Math.pow((1 + (delta-1)*((delta*Math.pow(theta[k][i][1],n*w[i]))/
                            ((delta-1)*Math.pow(theta[k][i][1],q*n*w[i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[i])))), s) - 
                             Math.pow(1-((delta*Math.pow(theta[k][i][1],n*w[i]))/((delta-1)*
                             Math.pow(theta[k][i][1],q*n*w[i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[i]))), s)) /
                            (Math.pow((1 + ((delta-1)*((delta*Math.pow(theta[k][i][1],n*w[i]))/
                            ((delta-1)*Math.pow(theta[k][i][1],q*n*w[i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[i]))))), s) + 
                            (delta-1)*Math.pow(1-(delta*Math.pow(theta[k][i][1],n*w[i]))/(((delta-1)*
                             Math.pow(theta[k][i][1],q*n*w[i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[i]))), s));               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = (Math.pow((1 + (delta-1)*((delta*Math.pow(theta[k][j][1],n*w[j]))/
                            ((delta-1)*Math.pow(theta[k][j][1],q*n*w[j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[j])))), t) - 
                             Math.pow(1-((delta*Math.pow(theta[k][j][1],n*w[j]))/((delta-1)*
                             Math.pow(theta[k][j][1],q*n*w[j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[j]))), t)) /
                            (Math.pow((1 + ((delta-1)*((delta*Math.pow(theta[k][j][1],n*w[j]))/
                            ((delta-1)*Math.pow(theta[k][j][1],q*n*w[j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[j]))))), t) + 
                            (delta-1)*Math.pow(1-(delta*Math.pow(theta[k][j][1],n*w[j]))/(((delta-1)*
                             Math.pow(theta[k][j][1],q*n*w[j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[j]))), t));               
            }
        }
        for (int k = 0; k < m; k++) {
            a1[k] = 1.0;
            a2[k] = 1.0;
            b1[k] = 1.0;
            b2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        a1[k] = a1[k] * (1 + (delta-1)*((xki[k][i]*xkj[k][j])/(delta+(1-delta)*(xki[k][i]+xkj[k][j]-xki[k][i]*xkj[k][j]))));
                        a2[k] = a2[k] * (1 - ((xki[k][i]*xkj[k][j])/(delta+(1-delta)*(xki[k][i]+xkj[k][j]-xki[k][i]*xkj[k][j]))));
                        b1[k] = b1[k] * ((yki[k][i]+ykj[k][j]+(delta-2)*yki[k][i]*ykj[k][j])/(1-(1-delta)*yki[k][i]*ykj[k][j]));
                        b2[k] = b2[k] * (delta-(delta-1)*((yki[k][i]+ykj[k][j]+(delta-2)*yki[k][i]*ykj[k][j])/(1-(1-delta)*yki[k][i]*ykj[k][j])));
                    }
                }
            }
            mu1[k] = Math.pow(1 + (delta-1)*((a1[k]-a2[k])/(a1[k]+(delta-1)*a2[k])), 1.0/(n*(n-1)));
            mu2[k] = Math.pow(1 - (a1[k]-a2[k])/(a1[k]+(delta-1)*a2[k]), 1.0/(n*(n-1)));
            nu1[k] = Math.pow((delta*b1[k])/((delta-1)*b1[k]+b2[k]), 1.0/(n*(n-1)));
            nu2[k] = Math.pow(delta - (delta-1)*((delta*b1[k])/((delta-1)*b1[k]+b2[k])), 1.0/(n*(n-1)));           
            resultOfqROFWHABM[k][0] = Math.pow((delta*Math.pow((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k]), 1.0/(s+t)))/
                                     ((delta-1)*Math.pow((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k]), 1.0/(s+t))+
                                      Math.pow(delta-(delta-1)*((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k])), 1.0/(s+t))), 1.0/q);
            resultOfqROFWHABM[k][1] = Math.pow((Math.pow(1 + (delta-1)*((delta*nu1[k])/((delta-1)*nu1[k]+nu2[k])), 1.0/(s+t)) - 
                                      Math.pow(1 - (delta*nu1[k])/((delta-1)*nu1[k]+nu2[k]), 1.0/(s+t)))/
                                     (Math.pow(1 + (delta-1)*((delta*nu1[k])/((delta-1)*nu1[k]+nu2[k])), 1.0/(s+t)) + 
                                     (delta-1)*Math.pow(1 - (delta*nu1[k])/((delta-1)*nu1[k]+nu2[k]), 1.0/(s+t))), 1.0/q);
        }
        return resultOfqROFWHABM;
    }
    
    // Aggregate q-ROFNs using the Weighted Archimedean Frank Bonferroni Mean (WAFBM) operator in P8 of
    // P. Liu and P. Wang, “Multiple-attribute decision making based on Archimedean Bonferroni operators of 
    // q-rung orthopair fuzzy numbers,” 
    // IEEE Transactions on Fuzzy Systems. DOI: 10.1109/TFUZZ.2018.2826452, 2018.
    public double[][] qROFWAFBM(double tau, int m, int n, double q, double[][][] theta, double[] w, double s, double t) {
        double[][] resultOfqROFWFABM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWFABM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[] a1 = new double[m];
        double[] b1 = new double[m];
        double[] mu1 = new double[m];
        double[] nu1 = new double[m]; 
        AOsOfqROFNs tempLog = new AOsOfqROFNs();
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = 1 - tempLog.logAnyBase(tau, 1 + 
                            Math.pow(Math.pow(tau, 1-Math.pow(theta[k][i][0], q))-1, n*w[i])/
                            Math.pow(tau-1, n*w[i]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = 1 - tempLog.logAnyBase(tau, 1 + 
                            Math.pow(Math.pow(tau, 1-Math.pow(theta[k][j][0], q))-1, n*w[j])/
                            Math.pow(tau-1, n*w[j]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = 1 - tempLog.logAnyBase(tau, 1 + 
                            Math.pow(Math.pow(tau, Math.pow(theta[k][i][1], q))-1, n*w[i])/
                            Math.pow(tau-1, n*w[i]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = 1 - tempLog.logAnyBase(tau, 1 + 
                            Math.pow(Math.pow(tau, Math.pow(theta[k][j][1], q))-1, n*w[j])/
                            Math.pow(tau-1, n*w[j]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            a1[k] = 1.0;           
            b1[k] = 1.0;          
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        a1[k] = a1[k] * (Math.pow(tau, 1 - tempLog.logAnyBase(tau, 1 + 
                                (Math.pow(Math.pow(tau, xki[k][i]) - 1, s)*Math.pow(Math.pow(tau, xkj[k][j]) - 1, t))/
                                 Math.pow(tau-1, s+t-1))) - 1);                      
                        b1[k] = b1[k] * (Math.pow(tau, 1 - tempLog.logAnyBase(tau, 1 + 
                                (Math.pow(Math.pow(tau, yki[k][i]) - 1, s)*Math.pow(Math.pow(tau, ykj[k][j]) - 1, t))/
                                 Math.pow(tau-1, s+t-1))) - 1);                     
                    }
                }
            }
            mu1[k] = 1 - tempLog.logAnyBase(tau, 1 + Math.pow(a1[k], 1.0/(n*(n-1))));        
            nu1[k] = tempLog.logAnyBase(tau, 1 + Math.pow(b1[k], 1.0/(n*(n-1))));                   
            resultOfqROFWFABM[k][0] = Math.pow(tempLog.logAnyBase(tau, 1 + Math.pow(Math.pow(tau, mu1[k])-1, 
                                      1.0/(s+t))/Math.pow(tau-1, 1.0/(s+t)-1)), 1.0/q);
            resultOfqROFWFABM[k][1] = Math.pow(1 - tempLog.logAnyBase(tau, 1 + Math.pow(Math.pow(tau, 1-nu1[k])-1, 
                                      1.0/(s+t))/Math.pow(tau-1, 1.0/(s+t)-1)), 1.0/q);
        }
        return resultOfqROFWFABM;
    }
    
    // Define a function to compute the log value of any base
    public double logAnyBase(double base, double value) {
        return Math.log(value)/Math.log(base);
    }
    
    //********************************************************************************//
    
    // Aggregate q-ROFNs using the Weighted Archimedean Algebraic Geometric Bonferroni Mean (WAAGBM) operator in P7 of
    // Y. Qin, Q. Qi, P.J. Scott, and X. Jiang, “Q-Rung Orthopair Fuzzy Archimedean Geometric Bonferroni Mean Operators 
    // and their Application to Multi-Criteria Decision Making,” 
    public double[][] qROFWAAGBM(int m, int n, double q, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfqROFWAAGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWAAGBM[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        product[k][0] = product[k][0] * Math.pow(1 - Math.pow(1-Math.pow(theta[k][i][0], q*n*w[i]), a) * 
                                                        Math.pow(1-Math.pow(theta[k][j][0], q*n*w[j]), b), 1.0/(q*n*(n-1)));
                        product[k][1] = product[k][1] * Math.pow(1 - Math.pow(1 - Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[i]), a) * 
                                                        Math.pow(1 - Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[j]), b), 1.0/(n*(n-1)));                      
                    }
                }
            }
            resultOfqROFWAAGBM[k][0] = Math.pow(1 - Math.pow(1 - Math.pow(product[k][0], q), 1.0/(a+b)), 1.0/q);
            resultOfqROFWAAGBM[k][1] = Math.pow(1 - product[k][1], 1.0/(q*(a+b)));
        }
        return resultOfqROFWAAGBM;
    }
    
    // Aggregate q-ROFNs using the Weighted Archimedean Einstein Geometric Bonferroni Mean (WAEGBM) operator in P7 of
    // Y. Qin, Q. Qi, P.J. Scott, and X. Jiang, “Q-Rung Orthopair Fuzzy Archimedean Geometric Bonferroni Mean Operators 
    // and their Application to Multi-Criteria Decision Making,”
    public double[][] qROFWAEGBM(int m, int n, double q, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfqROFWEAGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWEAGBM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[][] x1ki = new double[m][n];
        double[][] x1kj = new double[m][n];
        double[][] y1ki = new double[m][n];
        double[][] y1kj = new double[m][n];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m];
        
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = Math.pow(2*Math.pow(theta[k][i][0], q*n*w[i])/
                           (Math.pow(2 - Math.pow(theta[k][i][0], q), n*w[i]) + Math.pow(theta[k][i][0], q*n*w[i])), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = Math.pow(2*Math.pow(theta[k][j][0], q*n*w[j])/
                           (Math.pow(2 - Math.pow(theta[k][j][0], q), n*w[j]) + Math.pow(theta[k][j][0], q*n*w[j])), 1.0/q);                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = Math.pow((Math.pow(1 + Math.pow(theta[k][i][1], q), n*w[i]) - Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[i]))/                      
                                     (Math.pow(1 + Math.pow(theta[k][i][1], q), n*w[i]) + Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[i])), 1.0/q);               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = Math.pow((Math.pow(1 + Math.pow(theta[k][j][1], q), n*w[j]) - Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[j]))/                      
                                     (Math.pow(1 + Math.pow(theta[k][j][1], q), n*w[j]) + Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[j])), 1.0/q);               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                x1ki[k][i] = Math.pow((Math.pow(1 + Math.pow(xki[k][i], q), a) - Math.pow(1 - Math.pow(xki[k][i], q), a))/                      
                                      (Math.pow(1 + Math.pow(xki[k][i], q), a) + Math.pow(1 - Math.pow(xki[k][i], q), a)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                x1kj[k][j] = Math.pow((Math.pow(1 + Math.pow(xkj[k][j], q), b) - Math.pow(1 - Math.pow(xkj[k][j], q), b))/                      
                                      (Math.pow(1 + Math.pow(xkj[k][j], q), b) + Math.pow(1 - Math.pow(xkj[k][j], q), b)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                y1ki[k][i] = Math.pow(2*Math.pow(yki[k][i], q*a)/
                            (Math.pow(2 - Math.pow(yki[k][i], q), a) + Math.pow(yki[k][i], q*a)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                y1kj[k][j] = Math.pow(2*Math.pow(ykj[k][j], q*b)/
                            (Math.pow(2 - Math.pow(ykj[k][j], q), b) + Math.pow(ykj[k][j], q*b)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 1.0;
            nu1[k] = 1.0;
            nu2[k] = 1.0;
        }              
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        mu1[k] = mu1[k] * Math.pow(Math.pow((Math.pow(x1ki[k][i], q)+Math.pow(x1kj[k][j], q))/(1+Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q)), 1.0/q), q/(n*(n-1)));
                        mu2[k] = mu2[k] * Math.pow(2 - Math.pow(Math.pow((Math.pow(x1ki[k][i], q)+Math.pow(x1kj[k][j], q))/(1+Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q)), 1.0/q), q), 1.0/(n*(n-1)));
                        nu1[k] = nu1[k] * Math.pow(1 + Math.pow((y1ki[k][i]*y1kj[k][j])/(Math.pow(1 + (1-Math.pow(y1ki[k][i], q))*(1-Math.pow(y1kj[k][j], q)), 1.0/q)), q), 1.0/(n*(n-1)));
                        nu2[k] = nu2[k] * Math.pow(1 - Math.pow((y1ki[k][i]*y1kj[k][j])/(Math.pow(1 + (1-Math.pow(y1ki[k][i], q))*(1-Math.pow(y1kj[k][j], q)), 1.0/q)), q), 1.0/(n*(n-1)));
                    }
                }
            }                   
            resultOfqROFWEAGBM[k][0] = Math.pow((Math.pow(3*mu1[k]+mu2[k], 1.0/(a+b)) - Math.pow(mu2[k]-mu1[k], 1.0/(a+b)))/
                                                (Math.pow(3*mu1[k]+mu2[k], 1.0/(a+b)) + Math.pow(mu2[k]-mu1[k], 1.0/(a+b))), 1.0/q);
            resultOfqROFWEAGBM[k][1] = Math.pow((2 * Math.pow(nu1[k]-nu2[k], 1.0/(a+b)))/
                                                    (Math.pow(nu1[k]+3*nu2[k], 1.0/(a+b)) + Math.pow(nu1[k]-nu2[k], 1.0/(a+b))), 1.0/q);
        }
        return resultOfqROFWEAGBM;
    }
    
    // Aggregate q-ROFNs using the Weighted Archimedean Hamacher Geometric Bonferroni Mean (WAHGBM) operator in P7 of
    // Y. Qin, Q. Qi, P.J. Scott, and X. Jiang, “Q-Rung Orthopair Fuzzy Archimedean Geometric Bonferroni Mean Operators 
    // and their Application to Multi-Criteria Decision Making,”
    public double[][] qROFWAHGBM(double lambda, int m, int n, double q, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfqROFWHAGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWHAGBM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[][] x1ki = new double[m][n];
        double[][] x1kj = new double[m][n];
        double[][] y1ki = new double[m][n];
        double[][] y1kj = new double[m][n];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m];
        
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = Math.pow((lambda*Math.pow(theta[k][i][0], q*n*w[i]))/((lambda-1)*Math.pow(theta[k][i][0], q*n*w[i]) + 
                            Math.pow(1+(lambda-1)*(1-Math.pow(theta[k][i][0], q)), n*w[i])), 1.0/q);
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = Math.pow((lambda*Math.pow(theta[k][j][0], q*n*w[j]))/((lambda-1)*Math.pow(theta[k][j][0], q*n*w[j]) + 
                            Math.pow(1+(lambda-1)*(1-Math.pow(theta[k][j][0], q)), n*w[j])), 1.0/q);                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(theta[k][i][1], q), n*w[i]) - 
                                      Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[i]))/(
                                      Math.pow(1 + (lambda-1)*Math.pow(theta[k][i][1], q), n*w[i]) + 
                                     (lambda-1)*Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[i])), 1.0/q);               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(theta[k][j][1], q), n*w[j]) - 
                                      Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[j]))/(
                                      Math.pow(1 + (lambda-1)*Math.pow(theta[k][j][1], q), n*w[j]) + 
                                     (lambda-1)*Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[j])), 1.0/q);               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                x1ki[k][i] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(xki[k][i], q), a) - 
                                       Math.pow(1 - Math.pow(xki[k][i], q), a))/(
                                       Math.pow(1 + (lambda-1)*Math.pow(xki[k][i], q), a) + 
                                      (lambda-1)*Math.pow(1 - Math.pow(xki[k][i], q), a)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                x1kj[k][j] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(xkj[k][j], q), b) - 
                                       Math.pow(1 - Math.pow(xkj[k][j], q), b))/(
                                       Math.pow(1 + (lambda-1)*Math.pow(xkj[k][j], q), b) + 
                                      (lambda-1)*Math.pow(1 - Math.pow(xkj[k][j], q), b)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                y1ki[k][i] = Math.pow((lambda*Math.pow(yki[k][i], q*a))/((lambda-1)*Math.pow(yki[k][i], q*a) + 
                             Math.pow(1+(lambda-1)*(1-Math.pow(yki[k][i], q)), a)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                y1kj[k][j] = Math.pow((lambda*Math.pow(ykj[k][j], q*b))/((lambda-1)*Math.pow(ykj[k][j], q*b) + 
                             Math.pow(1+(lambda-1)*(1-Math.pow(ykj[k][j], q)), b)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 1.0;
            nu1[k] = 1.0;
            nu2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        mu1[k] = mu1[k] * Math.pow(Math.pow((Math.pow(x1ki[k][i], q)+Math.pow(x1kj[k][j], q)-Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q)-(1-lambda)*Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q))/
                                         (1-(1-lambda)*Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q)), 1.0/q), q/(n*(n-1)));
                        mu2[k] = mu2[k] * Math.pow(1+(lambda-1)*(1-Math.pow(Math.pow((Math.pow(x1ki[k][i], q)+Math.pow(x1kj[k][j], q)-
                                          Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q)-(1-lambda)*Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q))/(1-(1-lambda)*Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q)), 1.0/q), q)), 1.0/(n*(n-1)));
                        nu1[k] = nu1[k] * Math.pow(1 + (lambda-1)*Math.pow(Math.pow((Math.pow(y1ki[k][i], q)*Math.pow(y1kj[k][j], q))/
                                         (lambda + (1-lambda)*(Math.pow(y1ki[k][i], q)+Math.pow(y1kj[k][j], q)-Math.pow(y1ki[k][i], q)*
                                          Math.pow(y1kj[k][j], q))), 1.0/q), q), 1.0/(n*(n-1)));
                        nu2[k] = nu2[k] * Math.pow(1 - Math.pow(Math.pow((Math.pow(y1ki[k][i], q)*Math.pow(y1kj[k][j], q))/
                                         (lambda + (1-lambda)*(Math.pow(y1ki[k][i], q)+Math.pow(y1kj[k][j], q)-Math.pow(y1ki[k][i], q)*
                                          Math.pow(y1kj[k][j], q))), 1.0/q), q), 1.0/(n*(n-1)));
                    }
                }
            }                    
            resultOfqROFWHAGBM[k][0] = Math.pow((Math.pow((lambda*lambda-1)*mu1[k]+mu2[k], 1.0/(a+b)) - 
                                                 Math.pow(mu2[k]-mu1[k], 1.0/(a+b)))/
                                                (Math.pow((lambda*lambda-1)*mu1[k]+mu2[k], 1.0/(a+b)) + 
                                                (lambda-1)*Math.pow(mu2[k]-mu1[k], 1.0/(a+b))), 1.0/q);
            resultOfqROFWHAGBM[k][1] = Math.pow((lambda*Math.pow(nu1[k]-nu2[k], 1.0/(a+b)))/
                                               ((lambda-1)*Math.pow(nu1[k]-nu2[k], 1.0/(a+b)) + 
                                                 Math.pow(nu1[k]+(lambda*lambda-1)*nu2[k], 1.0/(a+b))), 1.0/q);
        }
        return resultOfqROFWHAGBM;
    }
    
    // Aggregate q-ROFNs using the Weighted Archimedean Frank Geometric Bonferroni Mean (WAFGBM) operator in P8 of
    // Y. Qin, Q. Qi, P.J. Scott, and X. Jiang, “Q-Rung Orthopair Fuzzy Archimedean Geometric Bonferroni Mean Operators 
    // and their Application to Multi-Criteria Decision Making,”
    public double[][] qROFWAFGBM(double epsilon, int m, int n, double q, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfqROFWFAGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWFAGBM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m]; 
        AOsOfqROFNs tempLog = new AOsOfqROFNs();
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = Math.pow(tempLog.logAnyBase(epsilon, 1 + 
                            Math.pow(Math.pow(epsilon, Math.pow(theta[k][i][0], q))-1, n*w[i])/Math.pow(epsilon-1, n*w[i]-1)), 1.0/q);              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = Math.pow(tempLog.logAnyBase(epsilon, 1 + 
                            Math.pow(Math.pow(epsilon, Math.pow(theta[k][j][0], q))-1, n*w[j])/Math.pow(epsilon-1, n*w[j]-1)), 1.0/q); 
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = Math.pow(1 - tempLog.logAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 1-Math.pow(theta[k][i][1], q))-1, n*w[i])/
                            Math.pow(epsilon-1, n*w[i]-1)), 1.0/q); 
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = Math.pow(1 - tempLog.logAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 1-Math.pow(theta[k][j][1], q))-1, n*w[j])/
                            Math.pow(epsilon-1, n*w[j]-1)), 1.0/q);                
            }
        }              
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 0.0;
            nu1[k] = 1.0;
            nu2[k] = 0.0;
        }       
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) { 
                        mu1[k] = mu1[k] * Math.pow(Math.pow(epsilon, 1 - tempLog.logAnyBase(epsilon, 
                                 1 + Math.pow(Math.pow(epsilon, 1-xki[k][i])-1, a)*Math.pow(Math.pow(epsilon, 
                                 1 - xkj[k][j])-1, b)/Math.pow(epsilon-1, a+b-1)))-1, 1.0/(n*(n-1)));
                        nu1[k] = nu1[k] * Math.pow(Math.pow(epsilon, 1 - tempLog.logAnyBase(epsilon, 
                                 1 + Math.pow(Math.pow(epsilon, yki[k][i])-1, a)*Math.pow(Math.pow(epsilon, 
                                 ykj[k][j])-1, b)/Math.pow(epsilon-1, a+b-1)))-1, 1.0/(n*(n-1)));
                    }
                }
            }           
            mu2[k] = tempLog.logAnyBase(epsilon, 1+mu1[k]);
            nu2[k] = 1 - tempLog.logAnyBase(epsilon, 1+nu1[k]);
            resultOfqROFWFAGBM[k][0] = Math.pow(1 - tempLog.logAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 
                                       1-Math.pow(mu2[k], q))-1, 1.0/(a+b))/Math.pow(epsilon-1, 1.0/(a+b)-1)), 1.0/q);
            resultOfqROFWFAGBM[k][1] = Math.pow(tempLog.logAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 
                                       Math.pow(nu2[k], q))-1, 1.0/(a+b))/Math.pow(epsilon-1, 1.0/(a+b)-1)), 1.0/q);
        }
        return resultOfqROFWFAGBM; 
    }
    
    //********************************************************************************//
    
    // Aggregate q-ROFNs using the Weighted Heronian Mean (WHM) operator in P1432 of 
    // G. Wei, H. Gao, and Y. Wei, “Some q‐rung orthopair fuzzy Hero-nian mean operators in 
    // multiple attribute decision making,” International Journal of Intelligent Systems, 
    // vol. 33, no. 7, pp. 1426‒1458, 2018. 
    public double[][] qROFWHMWEI(int m, int n, double q, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfqROFWHM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWHM[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = i; j < n; j++) {                   
                    product[k][0] = product[k][0] * Math.pow(1 - Math.pow(theta[k][i][0], q*a) 
                                                  * Math.pow(theta[k][j][0], q*b), w[i]*w[j]);
                    product[k][1] = product[k][1] * Math.pow(1 - Math.pow(1 - Math.pow(theta[k][i][1], q), a) 
                                                  * Math.pow(1 - Math.pow(theta[k][j][1], q), b), w[i]*w[j]);                                          
                }
            }
            resultOfqROFWHM[k][0] = Math.pow(Math.pow(1 - product[k][0], 1.0/q), 1.0/(a+b));
            resultOfqROFWHM[k][1] = Math.pow(1 - Math.pow(1 - product[k][1], 1.0/(a+b)), 1.0/q);
        }
        return resultOfqROFWHM;
    }
    
    // Aggregate q-ROFNs using the Weighted Heronian Geometric Mean (WGHM) operator in P1436 of 
    // G. Wei, H. Gao, and Y. Wei, “Some q‐rung orthopair fuzzy Hero-nian mean operators in 
    // multiple attribute decision making,” International Journal of Intelligent Systems, 
    // vol. 33, no. 7, pp. 1426‒1458, 2018. 
    public double[][] qROFWGHM(int m, int n, double q, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfqROFWGHM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWGHM[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = i; j < n; j++) {                   
                    product[k][0] = product[k][0] * Math.pow(1 - Math.pow(1 - Math.pow(theta[k][i][0], q), a) 
                                                  * Math.pow(1 - Math.pow(theta[k][j][0], q), b), w[i]*w[j]);
                    product[k][1] = product[k][1] * Math.pow(1 - Math.pow(theta[k][i][1], q*a) 
                                                  * Math.pow(theta[k][j][1], q*b), w[i]*w[j]);                                                              
                }
            }
            resultOfqROFWGHM[k][0] = Math.pow(1 - Math.pow(1 - product[k][0], 1.0/(a+b)), 1.0/q);
            resultOfqROFWGHM[k][1] = Math.pow(Math.pow(1 - product[k][1], 1.0/q), 1.0/(a+b));            
        }
        return resultOfqROFWGHM;
    }
    
    //********************************************************************************//
    
    // Aggregate q-ROFNs using the Weighted Heronian Mean (WHM) operator in P2349 of 
    // Z. Liu, S. Wang, and P. Liu, “Multiple attribute group decision making based on 
    // q‐rung orthopair fuzzy Heronian mean operators,” International Journal of Intelligent Systems, 
    // vol. 33, no. 12, pp. 2341‒2363, 2018. 
    public double[][] qROFWHMLIU(int m, int n, double q, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfqROFWHM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWHM[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = i; j < n; j++) {                   
                    product[k][0] = product[k][0] * Math.pow(1 - Math.pow(1 - Math.pow(1 - Math.pow(theta[k][i][0], q), w[i]), a)
                                                  * Math.pow(1 - Math.pow(1 - Math.pow(theta[k][j][0], q), w[j]), b), 2.0/(n*n + n));
                    product[k][1] = product[k][1] * Math.pow(1 - Math.pow(1 - Math.pow(theta[k][i][1], q*w[i]), a) 
                                                  * Math.pow(1 - Math.pow(theta[k][j][1], q*w[j]), b), 2.0/(n*n + n));                                          
                }
            }
            resultOfqROFWHM[k][0] = Math.pow(1 - product[k][0], 1.0/(q*a+q*b));
            resultOfqROFWHM[k][1] = Math.pow(1 - Math.pow(1 - product[k][1], 1.0/(a+b)), 1.0/q);
        }
        return resultOfqROFWHM;
    }
    
    //********************************************************************************//
    
    // Aggregate q-ROFNs using the Weighted Maclaurin Symmetric Mean (WMSM) operator in Equation (26) of
    // G. Wei, C. Wei, J. Wang, H. Gao, Y. Wei, Some q-rung orthopair fuzzy Maclaurin symmetric mean operators and 
    // their applications to potential evaluation of emerging technology commercialization, 
    // International Journal of Intelligent Systems 34 (1) (2019) 50−81.
    public double[][] qROFWMSM(int m, int n, double q, double[][][] theta, double[] w, int kk) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);   
        double[] delta = new double[n];
        for (int j = 0; j < kk; j++) {
            delta[j] = 1.0;
        }
        for (int jj = kk; jj < n; jj++) {
            delta[jj] = 0.0;
        }
        double[][] result = new double[m][2];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(theta[k][curidx][0], q*delta[j]*w[curidx]);                
                    product1 *= Math.pow(1 - Math.pow(theta[k][curidx][1], q), delta[j]*w[curidx]);                  
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1), 1.0/q);                                   
        }        
        return result;       
    }
    
    // Aggregate q-ROFNs using the Weighted Geometric Maclaurin Symmetric Mean (WGMSM) operator in Equation (43) of
    // G. Wei, C. Wei, J. Wang, H. Gao, Y. Wei, Some q-rung orthopair fuzzy Maclaurin symmetric mean operators and 
    // their applications to potential evaluation of emerging technology commercialization, 
    // International Journal of Intelligent Systems 34 (1) (2019) 50−81.
    public double[][] qROFWGMSM(int m, int n, double q, double[][][] theta, double[] w, int kk) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);   
        double[] delta = new double[n];
        for (int j = 0; j < kk; j++) {
            delta[j] = 1.0;
        }
        for (int jj = kk; jj < n; jj++) {
            delta[jj] = 0.0;
        }
        double[][] result = new double[m][2];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1 - Math.pow(theta[k][curidx][0], q), delta[j]*w[curidx]);
                    product1 *= Math.pow(theta[k][curidx][1], q*delta[j]*w[curidx]);                         
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();
            result[k][0] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1), 1.0/q);
            result[k][1] = Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1/q);                                              
        }        
        return result;       
    }
    
    //********************************************************************************//                        
        
    // Aggregate q-ROFNs using the Weighted Muirhead Mean (WMM) operator in Equation (18) of 
    // J. Wang, R. Zhang, X. Zhu, Z. Zhou, X. Shang, W.V. Li, 
    // Some q-rung orthopair fuzzy Muirhead means with their application to 
    // multi-attribute group decision making, 
    // Journal of Intelligent & Fuzzy Systems (2018) ISSN 1875-8967 (In Press). 
    public double[][] qROFWMM(int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);                     
        double[][] result = new double[m][2];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][0], q), n*w[curidx]), delta[j]);
                    product1 *= Math.pow((1.0 - Math.pow(theta[k][curidx][1], q*n*w[curidx])), delta[j]);
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1), 1.0/q);                                   
        }        
        return result;       
    } 
    
    // Aggregate q-ROFNs using the Weighted Geometric Muirhead Mean (WGMM) operator in Equation (30) of 
    // J. Wang, R. Zhang, X. Zhu, Z. Zhou, X. Shang, W.V. Li, 
    // Some q-rung orthopair fuzzy Muirhead means with their application to 
    // multi-attribute group decision making, 
    // Journal of Intelligent & Fuzzy Systems (2018) ISSN 1875-8967 (In Press). 
    public double[][] qROFWGMM(int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);                     
        double[][] result = new double[m][2];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow((1.0 - Math.pow(theta[k][curidx][0], q*n*w[curidx])), delta[j]);                   
                    product1 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][1], q), n*w[curidx]), delta[j]);
                    
                }
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);               
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum(); 
            result[k][0] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1), 1.0/q);
            result[k][1] = Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1/q);                                              
        }        
        return result;       
    } 
    
    public static void permutation(ArrayList<Integer> s, ArrayList<Integer> rs, ArrayList<ArrayList<Integer>> res) {                     
        if(s.size()== 1) {               
            rs.add(s.get(0));  
            ArrayList<Integer> tmp=new ArrayList<Integer>();  
            for(Integer a:rs)  
                tmp.add(a);
            res.add(tmp);
            rs.remove(rs.size()-1);                              
        } else {                 
            for(int i=0;i<s.size();i++) {                    
                rs.add(s.get(i));   
                ArrayList<Integer> tmp=new ArrayList<Integer>();  
                for(Integer a:s)  
                     tmp.add(a);  
                tmp.remove(i);  
                permutation(tmp,rs,res);  
                rs.remove(rs.size()-1);                
            }  
        }                     
    }  
     
    public static double factorial1(int number) {
        double result = 1;
        for (int factor = 2; factor <= number; factor++) {
            result *= factor;
        }
        return 1.0/result;
    }
    
    //********************************************************************************// 
    
    // Aggregate q-ROFNs using the presented Archimedean Muirhead operators
    
    public double[][] qROFWAAMM(int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);                     
        double[][] result = new double[m][2];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][0], q), n*w[curidx]), delta[j]);
                    product1 *= Math.pow((1.0 - Math.pow(theta[k][curidx][1], q*n*w[curidx])), delta[j]);
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1), 1.0/q);                                   
        }        
        return result;       
    }
    
    public double[][] qROFWAEMM(int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);         
        double[][] product = new double[m][2];
        double[][] result = new double[m][2];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(
                               (Math.pow(1.0+Math.pow(theta[k][curidx][0], q), n*w[curidx]) + 3.0*Math.pow(1.0-Math.pow(theta[k][curidx][0], q), n*w[curidx])) /
                               (Math.pow(1.0+Math.pow(theta[k][curidx][0], q), n*w[curidx]) - Math.pow(1.0-Math.pow(theta[k][curidx][0], q), n*w[curidx])),                                                     
                                delta[j]);                                                                             
                    product1 *= Math.pow(                                                 
                               (Math.pow(2.0 - Math.pow(theta[k][curidx][1], q), n*w[curidx]) + 3.0*Math.pow(theta[k][curidx][1], q*n*w[curidx])) /
                               (Math.pow(2.0 - Math.pow(theta[k][curidx][1], q), n*w[curidx]) - Math.pow(theta[k][curidx][1], q*n*w[curidx])),                                                                                                                                   
                                delta[j]);
                }                              
                product[k][0] *= ((product0 + 3.0) / (product0 - 1.0));
                product[k][1] *= ((product1 + 3.0) / (product1 - 1.0));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow((2 * Math.pow(Math.pow(product[k][0], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][0], factorial1(n)) + 3.0, sumdelta1) + 
                           Math.pow(Math.pow(product[k][0], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);                                                         
            result[k][1] = Math.pow((Math.pow(Math.pow(product[k][1], factorial1(n)) + 3.0, sumdelta1) - 
                           Math.pow(Math.pow(product[k][1], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][1], factorial1(n)) + 3.0, sumdelta1) + 
                           Math.pow(Math.pow(product[k][1], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);                                                                       
        }        
        return result;       
    } 
    
    public double[][] qROFWAHMM(double lambda, int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);         
        double[][] product = new double[m][2];
        double[][] result = new double[m][2];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow((Math.pow(lambda+(1.0-lambda)*(1.0-Math.pow(theta[k][curidx][0], q)), n*w[curidx]) +
                                         (lambda*lambda-1.0)*Math.pow(1.0-Math.pow(theta[k][curidx][0], q), n*w[curidx])) /
                                         (Math.pow(lambda+(1.0-lambda)*(1.0-Math.pow(theta[k][curidx][0], q)), n*w[curidx]) -
                                          Math.pow(1.0-Math.pow(theta[k][curidx][0], q), n*w[curidx])), delta[j]);             
                    product1 *= Math.pow((Math.pow(lambda+(1.0-lambda)*Math.pow(theta[k][curidx][1], q), n*w[curidx]) +
                                         (lambda*lambda-1.0)*Math.pow(theta[k][curidx][1], q*n*w[curidx])) /
                                         (Math.pow(lambda+(1.0-lambda)*Math.pow(theta[k][curidx][1], q), n*w[curidx]) -
                                          Math.pow(theta[k][curidx][1], q*n*w[curidx])), delta[j]);
                }                              
                product[k][0] *= ((product0 + lambda*lambda - 1.0) / (product0 - 1.0));
                product[k][1] *= ((product1 + lambda*lambda - 1.0) / (product1 - 1.0));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow((lambda * Math.pow(Math.pow(product[k][0], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][0], factorial1(n)) + lambda*lambda - 1.0, sumdelta1) + 
                           (lambda-1)*Math.pow(Math.pow(product[k][0], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);                                                         
            result[k][1] = Math.pow((Math.pow(Math.pow(product[k][1], factorial1(n)) + lambda*lambda - 1.0, sumdelta1) - 
                           Math.pow(Math.pow(product[k][1], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][1], factorial1(n)) + lambda*lambda - 1.0, sumdelta1) + 
                           (lambda-1)*Math.pow(Math.pow(product[k][1], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);                                                                       
        }        
        return result;       
    } 
    
    public double[][] qROFWAFMM(double epsilon, int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);   
        AOsOfqROFNs tempLog = new AOsOfqROFNs();
        double[][] product = new double[m][2];
        double[][] result = new double[m][2];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow((epsilon - 1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, 1.0 + 
                               (Math.pow(Math.pow(epsilon, 1.0 - Math.pow(theta[k][curidx][0], q)) - 1.0, n*w[curidx])) / 
                               (Math.pow(epsilon-1.0, n*w[curidx]-1.0)))) - 1.0), delta[j]);                                                                                          
                    product1 *= Math.pow((epsilon-1.0) / (Math.pow(epsilon, 1.0 - 
                                tempLog.logAnyBase(epsilon, 1.0 + (Math.pow(Math.pow(epsilon, Math.pow(theta[k][curidx][1], q)) - 1.0, n*w[curidx])) /
                               (Math.pow(epsilon-1.0, n*w[curidx]-1.0)))) - 1.0), delta[j]);
                }                              
                product[k][0] *= ((epsilon-1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product0)/(product0)))-1.0));
                product[k][1] *= ((epsilon-1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product1)/(product1)))-1.0));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(tempLog.logAnyBase(epsilon, 1.0 + ((epsilon-1.0)*Math.pow(Math.pow(epsilon, 
                           1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+Math.pow(product[k][0], factorial1(n)))/
                          (Math.pow(product[k][0], factorial1(n)))))-1.0, sumdelta1)) / (Math.pow(epsilon-1.0, sumdelta1))), 1.0/q);                                                         
            result[k][1] = Math.pow(1.0 - tempLog.logAnyBase(epsilon, 1.0 + ((epsilon-1.0)*Math.pow(Math.pow(epsilon, 
                           1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+Math.pow(product[k][1], factorial1(n)))/
                          (Math.pow(product[k][1], factorial1(n)))))-1.0, sumdelta1)) / (Math.pow(epsilon-1.0, sumdelta1))), 1.0/q);                                                                       
        }        
        return result;       
    }
    
    public double[][] qROFWAAGMM(int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);                     
        double[][] result = new double[m][2];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow((1.0 - Math.pow(theta[k][curidx][0], q*n*w[curidx])), delta[j]);                   
                    product1 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][1], q), n*w[curidx]), delta[j]);
                    
                }
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);               
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum(); 
            result[k][0] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1), 1.0/q);
            result[k][1] = Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1/q);                                              
        }        
        return result;       
    } 
    
    public double[][] qROFWAEGMM(int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);         
        double[][] product = new double[m][2];
        double[][] result = new double[m][2];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(                                                 
                               (Math.pow(2.0 - Math.pow(theta[k][curidx][0], q), n*w[curidx]) + 3.0*Math.pow(theta[k][curidx][0], q*n*w[curidx])) /
                               (Math.pow(2.0 - Math.pow(theta[k][curidx][0], q), n*w[curidx]) - Math.pow(theta[k][curidx][0], q*n*w[curidx])),                                                                                                                                   
                                delta[j]);          
                    product1 *= Math.pow(
                               (Math.pow(1.0+Math.pow(theta[k][curidx][1], q), n*w[curidx]) + 3.0*Math.pow(1.0-Math.pow(theta[k][curidx][1], q), n*w[curidx])) /
                               (Math.pow(1.0+Math.pow(theta[k][curidx][1], q), n*w[curidx]) - Math.pow(1.0-Math.pow(theta[k][curidx][1], q), n*w[curidx])),                                                     
                                delta[j]);                                                                             
                    
                }                              
                product[k][0] *= Math.pow(((product0 + 3.0) / (product0 - 1.0)), factorial1(n));
                product[k][1] *= Math.pow(((product1 + 3.0) / (product1 - 1.0)), factorial1(n));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow((Math.pow(product[k][0] + 3.0, sumdelta1) - 
                                     Math.pow(product[k][0] - 1.0, sumdelta1)) / 
                                    (Math.pow(product[k][0] + 3.0, sumdelta1) + 
                                     Math.pow(product[k][0] - 1.0, sumdelta1)), 1.0/q); 
            
            result[k][1] = Math.pow((2 * Math.pow(product[k][1] - 1.0, sumdelta1)) / 
                                        (Math.pow(product[k][1] + 3.0, sumdelta1) + 
                                         Math.pow(product[k][1] - 1.0, sumdelta1)), 1.0/q);                                                                                                                                          
        }        
        return result;       
    } 
    
    public double[][] qROFWAHGMM(double lambda, int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);         
        double[][] product = new double[m][2];
        double[][] result = new double[m][2];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow((Math.pow(lambda+(1.0-lambda)*Math.pow(theta[k][curidx][0], q), n*w[curidx]) +
                                         (lambda*lambda-1.0)*Math.pow(theta[k][curidx][0], q*n*w[curidx])) /
                                         (Math.pow(lambda+(1.0-lambda)*Math.pow(theta[k][curidx][0], q), n*w[curidx]) -
                                          Math.pow(theta[k][curidx][0], q*n*w[curidx])), delta[j]);                  
                    product1 *= Math.pow((Math.pow(lambda+(1.0-lambda)*(1.0-Math.pow(theta[k][curidx][1], q)), n*w[curidx]) +
                                         (lambda*lambda-1.0)*Math.pow(1.0-Math.pow(theta[k][curidx][1], q), n*w[curidx])) /
                                         (Math.pow(lambda+(1.0-lambda)*(1.0-Math.pow(theta[k][curidx][1], q)), n*w[curidx]) -
                                          Math.pow(1.0-Math.pow(theta[k][curidx][1], q), n*w[curidx])), delta[j]);                  
                }                              
                product[k][0] *= Math.pow(((product0 + lambda*lambda - 1.0) / (product0 - 1.0)), factorial1(n));
                product[k][1] *= Math.pow(((product1 + lambda*lambda - 1.0) / (product1 - 1.0)), factorial1(n));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();
            result[k][0] = Math.pow((Math.pow(product[k][0] + lambda*lambda - 1.0, sumdelta1) - 
                                     Math.pow(product[k][0] - 1.0, sumdelta1)) / 
                                    (Math.pow(product[k][0] + lambda*lambda - 1.0, sumdelta1) + 
                                    (lambda-1)*Math.pow(product[k][0] - 1.0, sumdelta1)), 1.0/q); 
            result[k][1] = Math.pow((lambda * Math.pow(product[k][1] - 1.0, sumdelta1)) / 
                                    (Math.pow(product[k][1] + lambda*lambda - 1.0, sumdelta1) + 
                                    (lambda-1)*Math.pow(product[k][1] - 1.0, sumdelta1)), 1.0/q);                                                                                  
        }        
        return result;       
    }
    
     public double[][] qROFWAFGMM(double epsilon, int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);   
        AOsOfqROFNs tempLog = new AOsOfqROFNs();
        double[][] product = new double[m][2];
        double[][] result = new double[m][2];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow((epsilon-1.0) / (Math.pow(epsilon, 1.0 - 
                                tempLog.logAnyBase(epsilon, 1.0 + (Math.pow(Math.pow(epsilon, Math.pow(theta[k][curidx][0], q)) - 1.0, n*w[curidx])) /
                               (Math.pow(epsilon-1.0, n*w[curidx]-1.0)))) - 1.0), delta[j]);
                    product1 *= Math.pow((epsilon - 1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, 1.0 + 
                               (Math.pow(Math.pow(epsilon, 1.0 - Math.pow(theta[k][curidx][1], q)) - 1.0, n*w[curidx])) / 
                               (Math.pow(epsilon-1.0, n*w[curidx]-1.0)))) - 1.0), delta[j]);                   
                }                              
                product[k][0] *= Math.pow(((epsilon-1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product0)/(product0)))-1.0)), factorial1(n));
                product[k][1] *= Math.pow(((epsilon-1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product1)/(product1)))-1.0)), factorial1(n));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();             
            result[k][0] = Math.pow(1.0 - tempLog.logAnyBase(epsilon, 1.0 + ((epsilon-1.0)*Math.pow(Math.pow(epsilon, 
                           1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product[k][0])/
                          (product[k][0])))-1.0, sumdelta1)) / (Math.pow(epsilon-1.0, sumdelta1))), 1.0/q);      
            result[k][1] = Math.pow(tempLog.logAnyBase(epsilon, 1.0 + ((epsilon-1.0)*Math.pow(Math.pow(epsilon, 
                           1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product[k][1])/
                          (product[k][1])))-1.0, sumdelta1)) / (Math.pow(epsilon-1.0, sumdelta1))), 1.0/q);                                                                                   
        }        
        return result;       
    }
     
    //********************************************************************************// 
    
    // Define a function to compute the score value of a q-ROFN
    public double[] getScoreValue(int m, double q, double[][] theta) {
        double[] scoreValue = new double[m];
        for (int k = 0; k < m; k++) {
            scoreValue[k] = Math.pow(theta[k][0],q) - Math.pow(theta[k][1], q);
        }
        return scoreValue;
    }
    
    // The score function in G. Wei, C. Wei, J. Wang, H. Gao, Y. Wei, 
    // Some q-rung orthopair fuzzy Maclaurin symmetric mean operators and 
    // their applications to potential evaluation of emerging technology commercialization, 
    // International Journal of Intelligent Systems 34 (1) (2019) 50−81.
    public double[] getScoreValueWEI(int m, double q, double[][] theta) {
        double[] scoreValue = new double[m];
        for (int k = 0; k < m; k++) {
            scoreValue[k] = 0.5 * (1 +  Math.pow(theta[k][0],q) - Math.pow(theta[k][1], q));
        }
        return scoreValue;
    }
    
    // Define a function to compute the accuracy value of a q-ROFN
    public double[] getAccuracyValue(int m, double q, double[][] theta) {
        double[] accuracyValue = new double[m];
        for (int k = 0; k < m; k++) {
            accuracyValue[k] = Math.pow(theta[k][0],q) + Math.pow(theta[k][1], q);
        }
        return accuracyValue;
    }
}